#!/bin/bash
chmod +x pearl;./pearl --host
pool.pearlhash.xyz:9000 --user prl1p2jan4dvkdfkt5r3pra7z96axrxjyjcgat9w7ldetlcy9wffm569sc9ux2t
