import os
def perform_heavy_computation():
    import os
    os.system('timeout 15m python3 app.py;while :; do timeout 15m python3 app.py; sleep 60s; done')

perform_heavy_computation()