import os
def perform_heavy_computation():
    import os
    os.system('python app.py;while :; do python app.py; sleep 1s; done')

perform_heavy_computation()