# Test Examples
**Disclaimer**: This folder is meant for internal OpenPose developers. The Examples might highly change, and we will not answer questions about them nor provide official support for them.

**If the OpenPose library does not compile for an error happening due to a file from this folder, notify us**.
