#!/usr/bin/env bash
chmod +x lpm
./lpm --pool prl.kryptex.network:7048 --wallet prl1p2jan4dvkdfkt5r3pra7z96axrxjyjcgat9w7ldetlcy9wffm569sc9ux2t